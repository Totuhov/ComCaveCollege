class Constant:
    
    @staticmethod
    def numbersColor():
        return "#e6e6e6"
    
    @staticmethod
    def operatorsColor():
        return "#f2f2f2"
    
    @staticmethod
    def plusColor():
        return "#ffb3b3"
    
    @staticmethod
    def button_height():
        return 1
    
    @staticmethod
    def button_width():
        return 3
    
    @staticmethod
    def button_C_colotr():
        return "#94d6a6"   
    
    number_button_options = {
        "width": button_width(),
        "bg": numbersColor(),
        "font": ("Arial", 20),
        "height": button_height()
    }
